package GameHandler.lottikarotti_main;

public class Main {
    public static void main(String[] args) {
        Game.launch(Game.class, args);
    }
}